const AWSXRay = require('aws-xray-sdk-core')
const AWS = AWSXRay.captureAWS(require('aws-sdk'))
const pinpoint = new AWS.Pinpoint({region: process.env.REGION}); 

// Make sure the SMS channel is enabled for the projectId that you specify.
// See: https://docs.aws.amazon.com/pinpoint/latest/userguide/channels-sms-setup.html

let endpointCount = 0;
let successCount = 0;
let failureCount = 0;
const UpdatePinpointEndpointService = require("./domains/UpdatePinpointEndPointService")

exports.handler = (event, context, callback) => {
  console.log('Received event:', event);
  endpointCount = 0;
  successCount = 0;
  failureCount = 0;
  if(event.body){
		const inputData = JSON.parse(event.body);
        //const emailUpdated = UpdatePinpointEndpointService.UpdateEmail(inputData);
		updateNumber(inputData,updateCallback,callback);
		//Create Email endpoint
		updateEmail(inputData,updateCallback,callback);
	
	}
	else{
        callback(null, {
            statusCode: 400,
            headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*"
            }, 
            body: JSON.stringify({status:'bad request',message:'payload not found'}),
        });
  }
  
};
function updateCallback(status,lambdaFnCallBack){
	console.log('In updateCallback with value :'+status);
	endpointCount++;
	if(status === 'yes'){
		successCount++;
	}else{
		failureCount++
	}
	if(endpointCount == 2){
		//All endpoints created
		console.log('All requests completed');
		if(successCount == endpointCount){
			//All requests succeeded
			lambdaFnCallBack(null, {
				statusCode: 200,
				headers: {
				  "Access-Control-Allow-Origin": "*",
				  "Access-Control-Allow-Headers": "*"
				}, 
				body: JSON.stringify({status:'success',message:'created endpoint'}),
			});
		}else{
			//Some or all requests failed
			lambdaFnCallBack(null, {
				statusCode: 500,
				headers: {
				  "Access-Control-Allow-Origin": "*",
				  "Access-Control-Allow-Headers": "*"
				}, 
				body: JSON.stringify({status:'failure',message:'one or all endpoints not created'}),
			});
			
		}
	}
}
function updateEmail(inputData, callbackFunction,callback){
    const emailUpdated = UpdatePinpointEndpointService.UpdateEmail(inputData);
    if(emailUpdated){
        callbackFunction("yes",callback);
    }else{
        callbackFunction("no",callback);
    }
	//createEndpoint(inputData.emailId, inputData.firstName, inputData.lastName, 'EMAIL',inputData.emailId,inputData.emailId,inputData.riskValue,callbackFunction,callback);
}
function updateNumber (inputData, callbackFunction,callback) {
  const mobileNumberUpdated = UpdatePinpointEndpointService.UpdateMobile(inputData);
  if(mobileNumberUpdated){
    callbackFunction("yes",callback);
  }else{
    callbackFunction("no",callback);
  }
}


