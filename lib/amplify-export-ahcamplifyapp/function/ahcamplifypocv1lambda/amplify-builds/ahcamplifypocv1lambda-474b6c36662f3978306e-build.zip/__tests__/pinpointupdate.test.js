//Test Pinpoint Mobile Number Validation

test('the mobile number is valid', async () => {
    const mock = jest
    .fn()
    .mockReturnValue({channelValue: '+64211106102',endpointId : '64211106102'})
    expect (mock().channelValue).toBeDefined();
    expect (mock().endpointId).toBeDefined();
});

//Invalid phone number - test

test('the mobile number is invalid', async () => {
    const mock = jest
    .fn()
    .mockReturnValue({channelValue: undefined,endpointId : undefined})
    expect (mock().channelValue).toBeUndefined();
    expect (mock().endpointId).toBeUndefined();
});
  


