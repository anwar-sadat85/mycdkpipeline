const CallPinPointUpdateAPI = require("../ports/CallPinpointUpdateAPI");

const UpdateEmail = async(inputData) => {
    const projectId = process.env.PINPOINTAPP;
    const params = {
        ApplicationId: projectId,
        // The Endpoint ID is equal to the cleansed phone number minus the leading
        // plus sign. This makes it easier to easily update the endpoint later.
        EndpointId: inputData.emailId,
        EndpointRequest: {
          ChannelType: 'EMAIL',
          Address: inputData.emailId,
          OptOut: 'NONE',
          Attributes:{
            Risk:[inputData.riskValue]
          },
          User: {
            UserId:inputData.userId,
            UserAttributes: {
              FirstName: [
                inputData.firstName
              ],
              LastName: [
                inputData.lastName
              ]
            }
          }
        }
      };
    const updateEmailResult = await CallPinPointUpdateAPI.UpdatePinpointEndpoint(params);
    return updateEmailResult;
}
const UpdateMobile = async(inputData) => {
    let updateMobileNumber = false;
    const destinationNumber = inputData.destinationNumber;
  
    const params = {
        NumberValidateRequest: {
        IsoCountryCode: 'NZ',
        PhoneNumber: destinationNumber
        }
    };

    const validatedParams = await CallPinPointUpdateAPI.ValidatePhoneNumberWithPinPoint(params, async function(validatedParams){
      console.log("validatedParams : "+validatedParams);
      if(validatedParams){
        console.log("channelValue : "+validatedParams.channelValue)
        console.log("endpointId : "+validatedParams.endpointId)
        if(validatedParams.channelValue && validatedParams.endpointId){
            const projectId = process.env.PINPOINTAPP;
            const params = {
                ApplicationId: projectId,
                // The Endpoint ID is equal to the cleansed phone number minus the leading
                // plus sign. This makes it easier to easily update the endpoint later.
                EndpointId: validatedParams.endpointId,
                EndpointRequest: {
                    ChannelType: 'SMS',
                    Address: validatedParams.channelValue,
                    OptOut: 'NONE',
                    Attributes:{
                        Risk:[inputData.riskValue]
                    },
                    User: {
                        UserId:inputData.userId,
                        UserAttributes: {
                        FirstName: [
                            inputData.firstName
                        ],
                        LastName: [
                            inputData.lastName
                        ]
                        }
                    }
                }

            };
            updateMobileNumber = await CallPinPointUpdateAPI.UpdatePinpointEndpoint(params);
            //return updateMobileNumber;
        }else{
            //return false;
            updateMobileNumber = false;
        }
    }else{
      //return false;
      updateMobileNumber = false
    }
    });
  return updateMobileNumber; 
    
}
module.exports.UpdateEmail = UpdateEmail;
module.exports.UpdateMobile = UpdateMobile;