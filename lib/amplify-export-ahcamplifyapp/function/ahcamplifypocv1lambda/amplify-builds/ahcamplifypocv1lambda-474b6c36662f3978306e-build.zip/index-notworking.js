const AWSXRay = require('aws-xray-sdk-core')
const AWS = AWSXRay.captureAWS(require('aws-sdk'))
const pinpoint = new AWS.Pinpoint({region: process.env.REGION}); 

// Make sure the SMS channel is enabled for the projectId that you specify.
// See: https://docs.aws.amazon.com/pinpoint/latest/userguide/channels-sms-setup.html

const PinpointEndpointHandler = require("./adapters/PinpointEndpointHandler")

exports.handler = (event, context, callback) => {
  console.log('Received event:', event);
  const lambdaResponse = PinpointEndpointHandler.RequestHanlder(event,callback);
  console.log("Lambda Response : "+JSON.stringify(lambdaResponse));
  callback(null, lambdaResponse);
};



