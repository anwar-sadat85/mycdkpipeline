const AWSXRay = require('aws-xray-sdk-core')
const AWS = AWSXRay.captureAWS(require('aws-sdk'))
const pinpoint = new AWS.Pinpoint({region: process.env.REGION}); 
const UpdatePinpointEndpoint = async(params) =>{
    let endpointUpdated = false;
    pinpoint.updateEndpoint(params, function(err,data) {
        if (err) {
          console.log(err, err.stack);
          endpointUpdated = false;
          //callbackFunction('no',callback);
        }
        else {
          console.log("successfully updated endpoint");
          endpointUpdated = true;
          //callbackFunction('yes',callback);
        }
      });
      return endpointUpdated;
}

const ValidatePhoneNumberWithPinPoint = async(params, callBackHandler) => {
  let validatedParams = {};
    pinpoint.phoneNumberValidate(params, function(err, data) {
        
        if (err) {
          console.log(err, err.stack);
         // return false;
        // callbackFunction('no',callback);
        }
        else {
          console.log(data);
          //return data;
          //callback call
          if (data['NumberValidateResponse']['PhoneTypeCode'] == 0) {
            channelValue = data['NumberValidateResponse']['CleansedPhoneNumberE164'];
            endpointId = data['NumberValidateResponse']['CleansedPhoneNumberE164'].substring(1);
            validatedParams.channelValue = channelValue;
            validatedParams.endpointId = endpointId;
            console.log("validatedParams.channelValue -- "+validatedParams.channelValue)
            console.log("validatedParams.endpointId -- "+validatedParams.endpointId)
            callBackHandler(validatedParams);
            //createEndpoint(event.emailId, event.firstName, event.lastName, 'SMS',channelValue,endpointId,event.riskValue,callbackFunction,callback);
          } else {
            console.log("Received a phone number that isn't capable of receiving "
                       +"SMS messages. No endpoint created.");
            callBackHandler(validatedParams);
            //return false;
            //callback call
            //callbackFunction('no',callback);
          }
        }
        
      });
      //console.log("Channel Value in Validate: "+channelValue );
      //console.log("endpointId in Validate: "+endpointId );
    //   let validatedParams = {
    //     channelValue:channelValue,
    //     endpointId: endpointId
    // }
    //return validatedParams;
}
module.exports.UpdatePinpointEndpoint = UpdatePinpointEndpoint;
module.exports.ValidatePhoneNumberWithPinPoint = ValidatePhoneNumberWithPinPoint;
