const AWSXRay = require('aws-xray-sdk-core')
const AWS = AWSXRay.captureAWS(require('aws-sdk'))
const pinpoint = new AWS.Pinpoint({region: process.env.REGION}); 

// Make sure the SMS channel is enabled for the projectId that you specify.
// See: https://docs.aws.amazon.com/pinpoint/latest/userguide/channels-sms-setup.html
const projectId = process.env.PINPOINTAPP;
let endpointCount = 0;
let successCount = 0;
let failureCount = 0;


exports.handler = (event, context, callback) => {
  console.log('Received event:', event);
  endpointCount = 0;
  successCount = 0;
  failureCount = 0;
  if(event.body){
		const inputData = JSON.parse(event.body);
		updateNumber(inputData,updateCallback,callback);
		//Create Email endpoint
		updateEmail(inputData,updateCallback,callback);
	
	}
	else{
    callback(null, {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "*"
        }, 
        body: JSON.stringify({status:'bad request',message:'payload not found'}),
    });
  }
  
};
function updateCallback(status,lambdaFnCallBack){
	console.log('In updateCallback with value :'+status);
	endpointCount++;
	if(status === 'yes'){
		successCount++;
	}else{
		failureCount++
	}
	if(endpointCount == 2){
		//All endpoints created
		console.log('All requests completed');
		if(successCount == endpointCount){
			//All requests succeeded
			lambdaFnCallBack(null, {
				statusCode: 200,
				headers: {
				  "Access-Control-Allow-Origin": "*",
				  "Access-Control-Allow-Headers": "*"
				}, 
				body: JSON.stringify({status:'success',message:'created endpoint'}),
			});
		}else{
			//Some or all requests failed
			lambdaFnCallBack(null, {
				statusCode: 500,
				headers: {
				  "Access-Control-Allow-Origin": "*",
				  "Access-Control-Allow-Headers": "*"
				}, 
				body: JSON.stringify({status:'failure',message:'one or all endpoints not created'}),
			});
			
		}
	}
}

function updateEmail(inputData, callbackFunction,callback){
	createEndpoint(inputData.emailId, inputData.firstName, inputData.lastName, 'EMAIL',inputData.emailId,inputData.emailId,inputData.riskValue,callbackFunction,callback);
}
function updateNumber (event, callbackFunction,callback) {
  const destinationNumber = event.destinationNumber;
  
  const params = {
    NumberValidateRequest: {
      IsoCountryCode: 'NZ',
      PhoneNumber: destinationNumber
    }
  };
  validatePhoneNumberWithPinPoint(params,event,callbackFunction,callback);
}

function validatePhoneNumberWithPinPoint(params,event,callbackFunction,callback){
  pinpoint.phoneNumberValidate(params, function(err, data) {
    if (err) {
      console.log(err, err.stack);
     // return false;
	 callbackFunction('no',callback);
    }
    else {
      console.log(data);
      //return data;
	  //callback call
      if (data['NumberValidateResponse']['PhoneTypeCode'] == 0) {
        const channelValue = data['NumberValidateResponse']['CleansedPhoneNumberE164'];
        const endpointId = data['NumberValidateResponse']['CleansedPhoneNumberE164'].substring(1);
		
        createEndpoint(event.emailId, event.firstName, event.lastName, 'SMS',channelValue,endpointId,event.riskValue,callbackFunction,callback);
      } else {
        console.log("Received a phone number that isn't capable of receiving "
                   +"SMS messages. No endpoint created.");
        //return false;
		//callback call
		callbackFunction('no',callback);
      }
    }
  });
  
}


function createEndpoint(userId, firstName, lastName, channelType, channelValue,endpointId, riskValue,callbackFunction,callback) {
  const params = {
    ApplicationId: projectId,
    // The Endpoint ID is equal to the cleansed phone number minus the leading
    // plus sign. This makes it easier to easily update the endpoint later.
    EndpointId: endpointId,
    EndpointRequest: {
      ChannelType: channelType,
      Address: channelValue,
      OptOut: 'NONE',
      Attributes:{
        Risk:[riskValue]
      },
      User: {
        UserId:userId,
        UserAttributes: {
          FirstName: [
            firstName
          ],
          LastName: [
            lastName
          ]
        }
      }
    }
  };
   updatePinPointEndpoint(params,callbackFunction,callback);
}

function updatePinPointEndpoint(params,callbackFunction,callback){
  pinpoint.updateEndpoint(params, function(err,data) {
    if (err) {
      console.log(err, err.stack);
      callbackFunction('no',callback);
    }
    else {
      console.log("successfully updated endpoint");
      callbackFunction('yes',callback);
    }
  });
  
}

